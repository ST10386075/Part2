﻿using System;
using System.Collections.Generic;

// Ingredient class representing each ingredient of a recipe
class Ingredient
{
    public string Name { get; set; }
    public float Quantity { get; set; }
    public string Unit { get; set; }
    public int Calories { get; set; }
    public string FoodGroup { get; set; }
}

// Recipe class representing a single recipe
class Recipe
{
    public string Name { get; set; }
    public List<Ingredient> Ingredients { get; set; }
    public List<string> Steps { get; set; }

    public Recipe(string name)
    {
        Name = name;
        Ingredients = new List<Ingredient>();
        Steps = new List<string>();
    }

    public int TotalCalories()
    {
        int totalCalories = 0;
        foreach (var ingredient in Ingredients)
        {
            totalCalories += ingredient.Calories;
        }
        return totalCalories;
    }
}

// RecipeManager class to manage recipes
class RecipeManager
{
    private List<Recipe> recipes;
    public delegate void RecipeCaloriesExceeded(string recipeName, int totalCalories);

    public RecipeManager()
    {
        recipes = new List<Recipe>();
    }

    // Add a new recipe
    public void AddRecipe(string name)
    {
        recipes.Add(new Recipe(name));
    }

    // Add an ingredient to a recipe
    public void AddIngredient(string recipeName, string name, float quantity, string unit, int calories, string foodGroup)
    {
        var recipe = recipes.Find(r => r.Name == recipeName);
        if (recipe == null)
        {
            Console.WriteLine("Recipe not found.");
            return;
        }
        recipe.Ingredients.Add(new Ingredient { Name = name, Quantity = quantity, Unit = unit, Calories = calories, FoodGroup = foodGroup });
    }

    // Add a step to a recipe
    public void AddStep(string recipeName, string step)
    {
        var recipe = recipes.Find(r => r.Name == recipeName);
        if (recipe == null)
        {
            Console.WriteLine("Recipe not found.");
            return;
        }
        recipe.Steps.Add(step);
    }

    // Display a list of all recipes
    public void DisplayRecipeList()
    {
        if (recipes.Count == 0)
        {
            Console.WriteLine("No recipes available.");
            return;
        }
        Console.WriteLine("Recipe List:");
        foreach (var recipe in recipes)
        {
            Console.WriteLine(recipe.Name);
        }
    }

    // Display the details of a specific recipe
    public void DisplayRecipeDetails(string recipeName)
    {
        var recipe = recipes.Find(r => r.Name == recipeName);
        if (recipe == null)
        {
            Console.WriteLine("Recipe not found.");
            return;
        }
        Console.WriteLine($"Recipe: {recipe.Name}");
        Console.WriteLine("Ingredients:");
        foreach (var ingredient in recipe.Ingredients)
        {
            Console.WriteLine($"{ingredient.Quantity} {ingredient.Unit} of {ingredient.Name}");
        }
        Console.WriteLine("Steps:");
        foreach (var step in recipe.Steps)
        {
            Console.WriteLine(step);
        }
        Console.WriteLine($"Total Calories: {recipe.TotalCalories()}");
        if (recipe.TotalCalories() > 300)
        {
            Console.WriteLine("Warning: This recipe exceeds 300 calories!");
        }
    }

    // Scale the quantities of ingredients in a recipe by a factor
    public void ScaleRecipe(string recipeName, float factor)
    {
        var recipe = recipes.Find(r => r.Name == recipeName);
        if (recipe == null)
        {
            Console.WriteLine("Recipe not found.");
            return;
        }
        foreach (var ingredient in recipe.Ingredients)
        {
            ingredient.Quantity *= factor;
        }
    }

    // Reset the quantities of ingredients in a recipe to original values
    public void ResetQuantities(string recipeName)
    {
        var recipe = recipes.Find(r => r.Name == recipeName);
        if (recipe == null)
        {
            Console.WriteLine("Recipe not found.");
            return;
        }
        // Reset to original values
    }

    // Clear all data to enter a new recipe
    public void ClearAllData()
    {
        recipes.Clear();
    }
}

class Program
{
    static void Main(string[] args)
    {
        RecipeManager recipeManager = new RecipeManager();

        while (true)
        {
            Console.WriteLine("Select an option:");
            Console.WriteLine("1. Add a recipe");
            Console.WriteLine("2. Add ingredients to a recipe");
            Console.WriteLine("3. Add steps to a recipe");
            Console.WriteLine("4. Display recipe details");
            Console.WriteLine("5. Scale recipe");
            Console.WriteLine("6. Reset quantities");
            Console.WriteLine("7. Clear all data");
            Console.WriteLine("8. Exit");
            Console.Write("Enter your choice: ");
            int choice = Convert.ToInt32(Console.ReadLine());

            switch (choice)
            {
                case 1:
                    Console.Write("Enter recipe name: ");
                    string recipeName = Console.ReadLine();
                    recipeManager.AddRecipe(recipeName);
                    break;
                case 2:
                    Console.Write("Enter recipe name: ");
                    recipeName = Console.ReadLine();
                    Console.Write("Enter ingredient name: ");
                    string ingredientName = Console.ReadLine();
                    Console.Write("Enter quantity: ");
                    float quantity = Convert.ToSingle(Console.ReadLine());
                    Console.Write("Enter unit: ");
                    string unit = Console.ReadLine();
                    Console.Write("Enter calories: ");
                    int calories = Convert.ToInt32(Console.ReadLine());
                    Console.Write("Enter food group: ");
                    string foodGroup = Console.ReadLine();
                    recipeManager.AddIngredient(recipeName, ingredientName, quantity, unit, calories, foodGroup);
                    break;
                case 3:
                    Console.Write("Enter recipe name: ");
                    recipeName = Console.ReadLine();
                    Console.Write("Enter step: ");
                    string step = Console.ReadLine();
                    recipeManager.AddStep(recipeName, step);
                    break;
                case 4:
                    Console.Write("Enter recipe name: ");
                    recipeName = Console.ReadLine();
                    recipeManager.DisplayRecipeDetails(recipeName);
                    break;
                case 5:
                    Console.Write("Enter recipe name: ");
                    recipeName = Console.ReadLine();
                    Console.Write("Enter scaling factor: ");
                    float factor = Convert.ToSingle(Console.ReadLine());
                    recipeManager.ScaleRecipe(recipeName, factor);
                    break;
                case 6:
                    Console.Write("Enter recipe name: ");
                    recipeName = Console.ReadLine();
                    recipeManager.ResetQuantities(recipeName);
                    break;
                case 7:
                    recipeManager.ClearAllData();
                    break;
                case 8:
                    Environment.Exit(0);
                    break;
                default:
                    Console.WriteLine("Invalid choice. Please enter a valid option.");
                    break;
            }
        }
    }
}
